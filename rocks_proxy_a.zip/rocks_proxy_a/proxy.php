<?php
// Rocks Proxy - Fast Option A
error_reporting(0);
ini_set('display_errors', 0);
set_time_limit(12);
ini_set('zlib.output_compression', '1');

$CACHE_TTL = 45;
$MAX_CONTENT_SIZE = 3000000;
$CACHE_DIR = __DIR__ . '/cache';
@mkdir($CACHE_DIR, 0755, true);

function fetch_curl($url) {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'RocksProxy/1.0';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_USERAGENT => $ua,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_TIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_ENCODING => '',
    ]);
    $data = curl_exec($ch);
    $info = curl_getinfo($ch);
    curl_close($ch);
    return [$data, $info];
}

function absoluteUrl($href, $base) {
    if (preg_match('#^https?://#i', $href)) return $href;
    if (strpos($href, '//') === 0) {
        $scheme = parse_url($base, PHP_URL_SCHEME) ?: 'https';
        return $scheme . ':' . $href;
    }
    if (preg_match('#^(data:|mailto:|javascript:|#)#i', $href)) return $href;
    $bp = parse_url($base);
    if (!$bp) return $href;
    $scheme = $bp['scheme'] ?? 'https';
    $host = $bp['host'] ?? '';
    $path = $bp['path'] ?? '/';
    if (substr($path, -1) !== '/') $path = substr($path, 0, strrpos($path, '/') + 1);
    if (strpos($href, '/') === 0) return "{$scheme}://{$host}{$href}";
    $full = "{$scheme}://{$host}{$path}{$href}";
    $parts = parse_url($full);
    $p = $parts['path'] ?? '/';
    $segs = explode('/', $p);
    $clean = [];
    foreach ($segs as $s) {
        if ($s === '' || $s === '.') continue;
        if ($s === '..') array_pop($clean);
        else $clean[] = $s;
    }
    $np = '/' . implode('/', $clean);
    $res = "{$parts['scheme']}://{$parts['host']}{$np}";
    if (!empty($parts['query'])) $res .= '?' . $parts['query'];
    return $res;
}

function rewrite_html_links($html, $baseUrl) {
    if (!$html) return $html;
    $cb = function($m) use ($baseUrl) {
        $attr = $m[1];
        $q = $m[2];
        $url = $m[3];
        if (preg_match('#^(data:|mailto:|javascript:|#)#i', $url)) return "{$attr}={$q}{$url}{$q}";
        $abs = absoluteUrl($url, $baseUrl);
        return "{$attr}={$q}?url=" . urlencode($abs) . "{$q}";
    };
    $html = preg_replace_callback('/\b(href|src|action)=([\'"])([^\'"]+)\2/i', $cb, $html);
    $html = preg_replace_callback('/<meta\s+http-equiv=["\']?refresh["\']?\s+content=["\']?[^;]+;url=([^"\'>]+)["\']?[^>]*>/i',
      function($m) use ($baseUrl) {
        $abs = absoluteUrl(trim($m[1]), $baseUrl);
        return '<meta http-equiv="refresh" content="0;url=?url=' . urlencode($abs) . '">';
      }, $html);
    $html = preg_replace_callback('/(window\.location(?:\.href)?\s*=\s*[\'"])([^\'"]+)([\'"])/i', function($m) use ($baseUrl) {
        $abs = absoluteUrl($m[2], $baseUrl);
        return $m[1] . '?url=' . urlencode($abs) . $m[3];
    }, $html);
    return $html;
}

$url = trim($_REQUEST['url'] ?? '');
if (!$url) {
    header("Location: index.php");
    exit;
}
if (!preg_match('#^https?://#i', $url)) $url = 'https://' . $url;

$cacheKey = hash('sha256', $url);
$cacheFile = $CACHE_DIR . '/' . $cacheKey . '.html';

if (file_exists($cacheFile) && (time() - filemtime($cacheFile) < $CACHE_TTL)) {
    readfile($cacheFile);
    exit;
}

list($data, $info) = fetch_curl($url);
$contentType = $info['content_type'] ?? 'text/html';

if ($data === false || $data === null) {
    header('Content-Type: text/html; charset=utf-8');
    echo "<html><body style='background:#f2f2f2;color:#111;font-family:Arial;padding:40px;text-align:center'><h3>Unable to load site.</h3><p><a href='./'>Return</a></p></body></html>";
    exit;
}

if (stripos($contentType, 'text/html') === false) {
    if ($contentType) header("Content-Type: $contentType");
    echo $data;
    exit;
}

if (strlen($data) > $MAX_CONTENT_SIZE) {
    $data = substr($data, 0, $MAX_CONTENT_SIZE) . "
<!-- truncated -->";
}

$rewritten = rewrite_html_links($data, $url);
@file_put_contents($cacheFile, $rewritten);
header('Content-Type: text/html; charset=UTF-8');
echo $rewritten;
exit;
