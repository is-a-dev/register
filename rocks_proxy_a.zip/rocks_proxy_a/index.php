<?php
// Rocks Proxy - Option A (Simple, Fast)
// Simple UI -> minimal design for max speed
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Rocks Proxy</title>
<style>
  html,body{height:100%;margin:0;font-family:Arial,Helvetica,sans-serif;background:#f2f2f2;color:#111}
  .wrap{height:100%;display:flex;align-items:center;justify-content:center}
  .box{width:92%;max-width:720px;padding:24px;background:#fff;border-radius:10px;box-shadow:0 10px 30px rgba(0,0,0,0.08);text-align:center}
  input{width:70%;padding:12px;border:1px solid #ddd;border-radius:6px;margin-right:8px;font-size:16px}
  button{padding:12px 18px;border-radius:6px;border:none;background:#007bff;color:#fff;font-weight:700;cursor:pointer}
  footer{margin-top:12px;color:#666;font-size:13px}
  @media(max-width:520px){input{width:60%}}
</style>
</head>
<body>
  <div class="wrap">
    <div class="box">
      <h2>Rocks Proxy</h2>
      <form id="f" onsubmit="return go(event)">
        <input id="u" placeholder="example.com or https://example.com" autocomplete="off" />
        <button type="submit">Go</button>
      </form>
      <div id="msg" style="margin-top:12px;color:#888;font-size:13px">Made for speed • PHP proxy</div>
      <footer>Made by Aarush Rao</footer>
    </div>
  </div>
<script>
function go(e){
  e?.preventDefault();
  var v=document.getElementById('u').value.trim();
  if(!v){ alert('Type a URL'); return false; }
  if(!/^https?:\/\//i.test(v)) v='https://'+v;
  location.href='?url='+encodeURIComponent(v);
  return false;
}
document.getElementById('u').addEventListener('keypress', function(e){ if(e.key==='Enter'){ e.preventDefault(); go(); } });
</script>
</body>
</html>
